<?php include('server.php');
if (isset($_GET['edit'])) {
	$id = $_GET['edit'];
	$edit_state = false;
	$rec = mysqli_query($db, "SELECT * FROM info WHERE id=$id");
	$record = mysqli_fetch_array($rec);
	$name = $record['name'];
	$address = $record['address'];
	$id = $record['id'];
}


?>

<!DOCTYPE html>
<html>
<head>
	<title>Accounts</title>
</head>
<body>

	<?php if (isset($_SESSION['msg'])) : ?>
		<div class="msg">
			<?php
			echo $_SESSION['msg'];
			unset($_SESSION['msg']);
			?>
		</div>
	<?php endif ?>

	<?php $results = mysqli_query($db, "SELECT * FROM info"); ?>
    <div class="box">
	<table>
		<thead>
			<tr>
				<th>Name</th>
				<th>Address</th>
				<th colspan="2">Action</th>
			</tr>
		</thead>

		<?php while ($row = mysqli_fetch_array($results)) { ?>
			<tr>
				<td><?php echo $row['name']; ?></td>
				<td><?php echo $row['address']; ?></td>
				<td>
					<a href="dashboard.php?edit=<?php echo $row['id']; ?>" class="edit_btn">Edit</a>
				</td>
				<td>
					<a href="server.php?del=<?php echo $row['id']; ?>" class="del_btn">Delete</a>
				</td>
			</tr>
		<?php } ?>
	</table>
    
	<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1">
    <title>Tesla admin</title>
    <link rel="stylesheet"
        href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <input type="checkbox" id="nav-toggle">    
    <div class="sidebar">
        <div class="sidebar-brand">
            <!-- <h2><span class="Tesla"></span>Tesla</h2> -->
            <img src="tesla-logo-png-2238.png" with="22px" height="22px" alt="">

        </div>

        <div class="sidebar-menu">
            <ul>
                <li>
                    <a href="dashboard.php"><span class="las la-igloo"></span>
                        <span>Dashboard</span></a>
                </li>
                <li>
                    <a href="accounts.php" class="active"><span class="lar la-user-circle"></span>
                        <span>Accounts</span></a>
                </li>
                <li>
                    <a href=""><span class="las la-shopping-bag"></span>
                        <span>Orders</span></a>
                </li>
            </ul>
        </div>
    </div>
    <div class="main-content">
        <header>
            <h2>
                <label for="nav-toggle">
                    <snap class="las la-bars"></snap>
                </label>
                <!-- Dashboard -->
            </h2>
            <div class="search-wrapper">
                <span class="las la-search"></span>
                <input type="search"  placeholder="Search here" />
            </div>

            <div class="user-wrapper">
                <!-- <img src="tesla-logo-png-2244.png" with="20px" height="20px" alt=""> -->
                <div>
                    <h4>Samir Kabashi</h4>
                    <small> Admin</small>
                </div>
            </div>
        </header>            
    </div>
</body>

</html>