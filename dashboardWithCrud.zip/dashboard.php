<?php include('server.php');
if (isset($_GET['edit'])) {
	$id = $_GET['edit'];
	$edit_state = false;
	$rec = mysqli_query($db, "SELECT * FROM info WHERE id=$id");
	$record = mysqli_fetch_array($rec);
	$name = $record['name'];
	$address = $record['address'];
	$id = $record['id'];
}


?>

<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<a></a>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<?php if (isset($_SESSION['msg'])) : ?>
		<div class="msg">
			<?php
			echo $_SESSION['msg'];
			unset($_SESSION['msg']);
			?>
		</div>
	<?php endif ?>

	<form method="post" action="server.php">
		<input type="hidden" name="id" value="<?php echo $id; ?>">
		<div class="input-group">
			<label>Name</label>
			<input type="text" name="name" value="<?php echo $name; ?>">
		</div>
		<div class="input-group">
			<label>Address</label>
			<input type="text" name="address" value="<?php echo $address; ?>">
		</div>
		<div class="input-group">
			<?php if ($update == true) : ?>
				<button class="btn" type="submit" name="update" style="background: #556B2F;">update</button>
			<?php else : ?>
				<button class="btn" type="submit" name="save">Save</button>
			<?php endif ?>
		</div>
	</form>
</body>

</html>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1">
    <link rel="stylesheet"
        href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <input type="checkbox" id="nav-toggle">    
    <div class="sidebar">
        <div class="sidebar-brand">
            <!-- <h2><span class="Tesla"></span>Tesla</h2> -->
            <img src="tesla-logo-png-2238.png" with="22px" height="22px" alt="">

        </div>

        <div class="sidebar-menu">
            <ul>
                <li>
                    <a href="" class="active"><span class="las la-igloo"></span>
                        <span>Dashboard</span></a>
                </li>
                <li>
                    <a href="accounts.php"><span class="lar la-user-circle"></span>
                        <span>Accounts</span></a>
                </li>
                <li>
                    <a href=""><span class="las la-shopping-bag"></span>
                        <span>Orders</span></a>
                </li>
            </ul>
        </div>
    </div>
    <div class="main-content">
        <header>
            <h2>
                <label for="nav-toggle">
                    <snap class="las la-bars"></snap>
                </label>
                <!-- Dashboard -->
            </h2>
            <div class="search-wrapper">
                <span class="las la-search"></span>
                <input type="search"  placeholder="Search here" />
            </div>

            <div class="user-wrapper">
                <!-- <img src="tesla-logo-png-2244.png" with="20px" height="20px" alt=""> -->
                <div>
                    <h4>Samir Kabashi</h4>
                    <small> Admin</small>
                </div>
            </div>
        </header>            
    </div>
</body>

</html>